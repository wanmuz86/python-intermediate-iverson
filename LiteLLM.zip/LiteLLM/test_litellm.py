import httpx
import openai
from pathlib import Path

# MANDATORY STEP!
# Need to download the CA bundle certificate to a local folder first
# The certificate can be downloaded from:
# https://confluencewikiprod.intra.infineon.com/download/attachments/1175312833/ca-bundle.crt?version=1&modificationDate=1702385678000&api=v2

# Below is local path to the downloaded certificate
CERT_PATH = "ca-bundle.crt"

# LiteLLM Settings
BASE_URL = "https://litellm.icp.infineon.com"  # LiteLLM Proxy is OpenAI compatible, Read More: https://docs.litellm.ai/docs/proxy/user_keys
API_KEY_1 = "3vpw5Cv_knAstOTm586"
API_KEY_2 = "VdzNV352wAfyfJkpL6w"
API_KEY_3 = "o43wvo9wfewgNnZnxJP"
API_KEY_4 = "tJo_4ZEYtLtegfgXEWt"

# Setup OpenAI client
client = openai.OpenAI(
    api_key = API_KEY_4,
    base_url = BASE_URL,
    http_client=httpx.Client(verify=CERT_PATH)
)

# Test with a simple chat completion
print("\nTesting chat completion...")

# Possible models: "gpt-5.2" or "llama3.3-70b"
completion = client.chat.completions.create(
    model="gpt-5.2",
    messages=[{"role": "user", "content": "Write a simple poem."}]
)

print(f"Response: {completion.choices[0].message.content}")
