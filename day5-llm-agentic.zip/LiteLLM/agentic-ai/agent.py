from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from dotenv import load_dotenv
import httpx
import os
from langchain_chroma import Chroma
from langchain.tools import tool
from openai import OpenAI
from langchain.agents import create_agent



# Create an LLM 
# LLM will be the brain of the agent the agent we are going to create

# Load the API key from .env

# Below is local path to the downloaded certificate
CERT_PATH = "ca-bundle.crt"

# LiteLLM Settings
BASE_URL = "https://litellm.icp.infineon.com"

load_dotenv()

# Change this to connect to LiteLLM
# to connect to litellm
llm = ChatOpenAI(
    model="gpt-5.2",
    # 0 means follow, the rules, 2 - means creative
    # Agents normally we need smaller temperature
    # We don't want agent to solve the issue from the model
    # We want the agent to get it from the tools
    temperature=0.2,
    api_key = os.getenv("OPENAI_API_KEY"),
    base_url = BASE_URL,
    http_client=httpx.Client(verify=CERT_PATH)
    
)

# to create the memory for the agent
# using Vector Database
# Chroma, Quadrant, Pinecode

embeddings = OpenAIEmbeddings()

memory_db = Chroma(
    collection_name="agent_memory",
    embedding_function=embeddings,
    persist_directory='./chromadb'
)

# web client to search information on the web (to be used later by the agent)
oai_client = OpenAI(  
    api_key = os.getenv("OPENAI_API_KEY"),
    base_url = BASE_URL,
    http_client=httpx.Client(verify=CERT_PATH)
    )

# The first tool that we provide to our agent is web
# It is used to search for any information

@tool("web_search", description="Search the web using OpenAI's built-in search tool.")
def web_search(query: str) -> str:
    """Use OpenAI Search to get up-to-date information."""
    response = oai_client.responses.create(
    model="gpt-5.2",
    input=query,
    tools=[{"type": "web_search"}],
    tool_choice={"type": "web_search"},
    )
    # Prefer structured output if available
    if hasattr(response, "output_text"):
        return response.output_text
    return str(response)

# When creating a tool , the description and commnet will be used by agent to reason 
# reason - select the right tool
@tool("calculator", description="Evaluate a math expression.")
def calculator(expression: str) -> str:
    """Evaluate a mathematical expression and return the result as text."""
    try:
        return str(eval(expression))
    except Exception:
        return "Error evaluating expression."

# Tool for file writing
# For simplicity, it will be writien in output.txt file

@tool("file_writer", description="Write content into output.txt.")
def file_writer(content: str) -> str:
    """Write the given content into output.txt and return a status message."""
    with open("output.txt", "a") as f:
        f.write(content)
    return "File saved to output.txt"


# Tool to save information in memory
# The memory is from ChromaDB created in Step 3

@tool("memory_save", description="Store information in long-term vector memory.")
def memory_save(text: str) -> str:
    """Store the given text in the agent's long-term memory."""
    memory_db.add_texts([text])
    return "Memory saved."

# Tool to retrieve information from the memory
@tool("memory_search", description="Retrieve information from long-term memory.")
def memory_search(query: str) -> str:
    """Search long-term memory and return the top matching items."""
    results = memory_db.similarity_search(query, k=3)
    return "\n".join([r.page_content for r in results])

# All tools need to be registered to be passed to the agent

# MCP - Model Context Protocol - [API for agents] - to create API listing all the available tools
# For agent (ongoing reseatch)
# Led by Anthropic - claude
tools = [web_search, calculator, file_writer, memory_save, memory_search]


# Create an agent
agent = create_agent(
    model=llm, # the brain of the agent 
    # In agentic AI, the model will become the brain
    # Agent use the brain/model to reason
    # WHat to do? Which tool should I use ? And then do it
    # stochastic -> random, there is know guarantee of flow arangement -> agentic AI
    # deterministic -> it follows a certain flow -> workflow
    tools=tools, # the tools provided for the agent
)

def ask_agent(prompt: str) -> str:
    """Send a user message to the agent and return the final answer."""
    print(f"\n---- ASK AGENT ----\n{prompt}\n-------------------")
    state = agent.invoke({
    "messages": [
        {"role": "user", "content": prompt},
        {"role":"system", "content":"You are an miscelleanous agent that help me with day to day job,"
        "ONLY USE the tool provided to resolve the given problem, if there is no tool suitable"
        "for the task you answer 'I dont know how to resolve the issue'."
        "For all tasks perform, add it in your memory"}

        ]
    })
    print("---- RAW STATE ----")
    print(state)
    print("-------------------")
    return state["messages"][-1].content

if __name__ == "__main__":
    # Test 1: Web search + reasoning
    # print(
    # ask_agent("Find top 3 AWS security updates today and summarize them. Once found write the result in a file")
    # )


    print(
        ask_agent("What is 3+2?")
    )

    print(
        ask_agent("What is 10+5 and write the answer in the file")
    )

    print(ask_agent("Send an email to wanmuz86@gmail.com to tell i ll be absent tomorrow afternoon"))

    print(ask_agent("Summarize what you have done so far?"))