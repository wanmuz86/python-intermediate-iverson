import os
import json
from dataclasses import dataclass, asdict
from datetime import date
from dotenv import load_dotenv
from openai import OpenAI
import httpx

# load the configuration from .env file
load_dotenv()

# LiteLLM Settings
BASE_URL = "https://litellm.icp.infineon.com"  # LiteLLM Proxy is OpenAI compatible, Read More: https://docs.litellm.ai/docs/proxy/user_keys

# Below is local path to the downloaded certificate
CERT_PATH = "ca-bundle.crt"

# Create a generic openAI client
# with the API key from .env

# We need to modify this line to use the LiteLLM version
# client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

client = OpenAI(
    api_key = os.getenv("OPENAI_API_KEY"),
    base_url = BASE_URL, # line 13
    http_client=httpx.Client(verify=CERT_PATH) # line 16 , and import httpx
)

# Creating class that will be passed through the prompt
# name (client name), days - 3, budget - 3000, style- business, destination type - beach
# constraints - Spend one day for shopping
@dataclass
class VacationRequest:
    name: str
    days: int
    budget: int
    style: str
    destination_type: str
    constraints: str

# Creating the user prompt

def build_prompt(req: VacationRequest) -> str:
    return f"""
You are a professional travel planner.

Create a {req.days}-day vacation plan.

Traveler: {req.name}
Budget: {req.budget} (The bugdet should in Malaysia Ringgit)
Travel style: {req.style}
Destination type: {req.destination_type}
Constraints: {req.constraints}

Output format:
1) Summary (3 bullets)
2) Day-by-day itinerary
3) Budget breakdown
4) Packing list
5) Safety tips
"""
# Calling LiteLLM OpenAI

def call_openai(prompt: str) -> str:
    try:
        response = client.chat.completions.create(
            model="gpt-5.2",  # 5.2 or ollama
            messages=[
                {"role": "system", "content": "You are a structured travel planner."},
                {"role": "user", "content": prompt}
            ],
             # temperatiure is AI creativity (0-2)
             # The higher the number the more creative it will be
             # FOR RAG - temperature needs to be 0
             # for creative writing and drawing - temperature can be bigger
            temperature=0.7, # temperatiure is AI creativity
        )
        return response.choices[0].message.content # retun the response from API

    except Exception as e:
        return f"[ERROR] OpenAI API call failed: {e}"

# Build and call the prompt
# This method will be called by the button on streamlit or FastAPI
def make_plan(req: VacationRequest) -> dict:
    prompt = build_prompt(req)
    plan_text = call_openai(prompt)

    # It return back to streamlit or FastAPI using JSON {}
    return {
        "generated_on": str(date.today()),
        "request": asdict(req), # request
        "plan_text": plan_text, # response
    }


# save the plan created in txt and json, filename is vacation_report
# similar to lab 15
def save_reports(plan: dict, base_name="vacation_report"):
    with open(f"{base_name}.txt", "w", encoding="utf-8") as f:
        f.write(plan["plan_text"])

    with open(f"{base_name}.json", "w", encoding="utf-8") as f:
        json.dump(plan, f, indent=2)

    print("✅ Reports saved.")
