from fastapi import FastAPI
from pydantic import BaseModel
from planner import VacationRequest, make_plan, save_reports
from fastapi.responses import FileResponse


# Create an API  using FastAPI
app = FastAPI(title="AI Vacation Planner")

# JSON Request type
# {"name":"", "days":3, "budget":3000, "style":"budget, backpacking", 
# "destination_type":"beach, hiking"
#, constraints: "reserve one day for shopping"}
class VacationRequestIn(BaseModel):
    name: str
    days: int
    budget: int
    style: str
    destination_type: str
    constraints: str = ""

# Create a POST request, that accept the above JSON as body
# call the make_plan method
# call the save_reports method
# /plan
@app.post("/plan")
def generate_plan(req: VacationRequestIn):
    plan = make_plan(VacationRequest(**req.dict()))
    save_reports(plan)

    return {
        "preview": plan["plan_text"][:300],
        "download_txt": "/download/txt",
        "download_json": "/download/json"
    }

# Create a GET request
# the url is /download/txt 
# it will return vacation_report.txt
@app.get("/download/txt")
def download_txt():
    return FileResponse("vacation_report.txt")

# Create a GET request
# the url is /download/json 
# it will return vacation_report.json
@app.get("/download/json")
def download_json():
    return FileResponse("vacation_report.json")
