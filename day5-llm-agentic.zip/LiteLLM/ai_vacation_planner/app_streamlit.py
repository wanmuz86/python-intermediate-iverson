import streamlit as st
from planner import VacationRequest, make_plan, save_reports

st.title("AI Vacation Planner 🌍") # <h1> 

name = st.text_input("Name", "Aina") # input
days = st.slider("Days", 1, 14, 3) # slider 
budget = st.number_input("Budget (MYR)", 100, 10000, 1500) # number input
style = st.selectbox("Style", ["relax", "adventure", "family", "food"]) # tick
destination = st.selectbox("Destination type", ["beach", "city", "nature"]) # drop down menu
constraints = st.text_area("Constraints") #textarea

# button
# when the button is pressed
# we create the plan request - line 20
# call the api - line 28
# save in file - line 29
if st.button("Generate Plan"):
    req = VacationRequest(
        name=name,
        days=days,
        budget=budget,
        style=style,
        destination_type=destination,
        constraints=constraints
    )

    plan = make_plan(req)
    save_reports(plan)

    st.subheader("Plan Preview")  # Once done the plan will be showed here
    st.text(plan["plan_text"]) 

    st.download_button( # button to download
        "Download TXT",
        data=open("vacation_report.txt").read(),
        file_name="vacation_report.txt"
    )

    st.download_button(
        "Download JSON",
        data=open("vacation_report.json").read(),
        file_name="vacation_report.json"
    )
